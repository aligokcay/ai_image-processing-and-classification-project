import matplotlib.pyplot as plt
import numpy as np

# Verileri oku (GD, SGD, Adam sonuçları)
gd_data = np.loadtxt('c:/Users/Mehmet Ali/Desktop/Department/2/optimization/project/results/results_gd.txt', delimiter=' ')
sgd_data = np.loadtxt('c:/Users/Mehmet Ali/Desktop/Department/2/optimization/project/results/results_sgd.txt', delimiter=' ')
adam_data = np.loadtxt('c:/Users/Mehmet Ali/Desktop/Department/2/optimization/project/results/results_adam.txt', delimiter=' ')

# Epochlar, Train Loss ve Train Accuracy için her bir algoritma
epochs_gd = gd_data[:, 0]
train_losses_gd = gd_data[:, 1]
train_accuracies_gd = gd_data[:, 2]
train_times_gd = gd_data[:, 3]

test_losses_gd = gd_data[:, 4]
test_accuracies_gd = gd_data[:, 5]

epochs_sgd = sgd_data[:, 0]
train_losses_sgd = sgd_data[:, 1]
train_accuracies_sgd = sgd_data[:, 2]
train_times_sgd = sgd_data[:, 3]
test_losses_sgd = sgd_data[:, 4]
test_accuracies_sgd = sgd_data[:, 5]

epochs_adam = adam_data[:, 0]
train_losses_adam = adam_data[:, 1]
train_accuracies_adam = adam_data[:, 2]
train_times_adam = adam_data[:, 3]
test_losses_adam = adam_data[:, 4]
test_accuracies_adam = adam_data[:, 5]

# GD Epoch vs Loss grafiği
plt.figure(figsize=(10, 6))
plt.plot(epochs_gd, train_losses_gd, label='GD Train Loss', color='blue')
plt.plot(epochs_gd, test_losses_gd, label='GD Test Loss', color='orange')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Epochs vs Loss for GD')
plt.legend()
plt.show()

# SGD Epoch vs Loss grafiği
plt.figure(figsize=(10, 6))
plt.plot(epochs_sgd, train_losses_sgd, label='SGD Train Loss', color='blue')
plt.plot(epochs_sgd, test_losses_sgd, label='SGD Test Loss', color='orange')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Epochs vs Loss for SGD')
plt.legend()
plt.show()

# ADAM Epoch vs Loss grafiği
plt.figure(figsize=(10, 6))
plt.plot(epochs_adam, train_losses_adam, label='ADAM Train Loss', color='blue')
plt.plot(epochs_adam, test_losses_adam, label='ADAM Test Loss', color='orange')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Epochs vs Loss for ADAM')
plt.legend()
plt.show()

# Epoch vs Loss grafiği
plt.figure(figsize=(10, 6))
plt.plot(epochs_gd, train_losses_gd, label='GD Loss', color='blue')
plt.plot(epochs_sgd, train_losses_sgd, label='SGD Loss', color='orange')
plt.plot(epochs_adam, train_losses_adam, label='Adam Loss', color='red')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Epochs vs Loss for GD, SGD and Adam')
plt.legend()
plt.show()

# Time vs Loss grafiği
plt.figure(figsize=(10, 6))
plt.plot(train_times_gd, train_losses_gd, label='GD Loss', color='blue')
plt.plot(train_times_sgd, train_losses_sgd, label='SGD Loss', color='orange')
plt.plot(train_times_adam, train_losses_adam, label='Adam Loss', color='red')
plt.xlabel('Time')
plt.ylabel('Loss')
plt.title('Time vs Loss for GD, SGD and Adam')
plt.legend()
plt.show()

# Time vs Epoch grafiği
plt.figure(figsize=(10, 6))
plt.plot(train_times_gd, epochs_gd, label='GD', color='blue')
plt.plot(train_times_sgd, epochs_sgd, label='SGD', color='orange')
plt.plot(train_times_adam, epochs_adam, label='Adam', color='red')
plt.xlabel('Time')
plt.ylabel('Epochs')
plt.title('Time vs Epochs for GD, SGD and Adam')
plt.legend()
plt.show()

# Epoch vs Accuracy grafiği
plt.figure(figsize=(10, 6))
plt.plot(epochs_gd, train_accuracies_gd, label='GD Accuracy', color='blue')
plt.plot(epochs_sgd, train_accuracies_sgd, label='SGD Accuracy', color='orange')
plt.plot(epochs_adam, train_accuracies_adam, label='Adam Accuracy', color='red')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.title('Epochs vs Accuracy for GD, SGD and Adam')
plt.legend()
plt.show()
